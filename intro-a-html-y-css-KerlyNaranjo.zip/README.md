### Clase 01 Intro a HTML y CSS

Realizar la página web que se encuentra en la imagen utilizando únicamente HTML y CSS sin ayuda de ningún framework.